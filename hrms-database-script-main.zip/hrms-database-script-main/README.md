# 🛢 Entity Relationship Diagram

![hrmsEntityRelationshipDiagram](https://res.cloudinary.com/merveucer/image/upload/v1632479113/gitHub/hrmsEntityRelationshipDiagram_h5fmg5.png)